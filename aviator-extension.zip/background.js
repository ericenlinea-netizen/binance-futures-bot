/**
 * Background Service Worker
 * Receives round captures from content scripts / popup, calls the dashboard API.
 */

const DEDUP_WINDOW_MS = 3000;
let lastSent = { multiplier: null, time: 0 };

// ─── Message handler ──────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

  if (msg.type === "ROUND_CAPTURED") {
    handleRound(msg.multiplier, msg.source ?? "auto")
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: false }));
    return true; // keep channel open
  }

  if (msg.type === "MANUAL_ROUND") {
    handleRound(msg.multiplier, "manual")
      .then((result) => sendResponse({ ok: true, signal: result?.signal, galeAlert: result?.galeAlert ?? null, signal20: result?.signal20 ?? null }))
      .catch((err) => sendResponse({ ok: false, error: String(err) }));
    return true; // keep channel open
  }

  if (msg.type === "GET_STATUS") {
    chrome.storage.local.get(["apiUrl", "lastRounds", "totalCaptures"], (data) => {
      sendResponse(data ?? {});
    });
    return true; // keep channel open
  }

  if (msg.type === "SET_API_URL") {
    chrome.storage.local.set({ apiUrl: msg.url }, () => sendResponse({ ok: true }));
    return true;
  }

  if (msg.type === "CLEAR_HISTORY") {
    chrome.storage.local.set({ lastRounds: [], totalCaptures: 0 }, () => sendResponse({ ok: true }));
    return true;
  }

  // Unhandled — respond immediately to avoid channel errors
  sendResponse({ ok: false, error: "unknown message type" });
  return false;
});

// ─── Core round handler ───────────────────────────────────────────────────────
async function handleRound(multiplier, source) {
  if (!multiplier || isNaN(multiplier)) return null;

  const now = Date.now();
  if (
    lastSent.multiplier === multiplier &&
    now - lastSent.time < DEDUP_WINDOW_MS &&
    source !== "manual"
  ) return null;

  lastSent = { multiplier, time: now };

  const { apiUrl } = await chrome.storage.local.get("apiUrl");
  const base = (apiUrl ?? "").trim();

  if (!base) {
    await updateLocalHistory(multiplier, "error", "URL no configurada");
    return null;
  }

  const endpoint = base.replace(/\/+$/, "") + "/api/rounds";

  try {
    const res = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ multiplier }),
    });

    if (!res.ok) {
      const txt = await res.text().catch(() => "");
      throw new Error(`HTTP ${res.status}: ${txt.slice(0, 100)}`);
    }

    const data = await res.json();
    // POST /rounds wraps signal as { signal: DualSignalResult, galeAlert, ... }
    // DualSignalResult = SignalResult + { signal20: SignalResult }
    const signal = data?.signal ?? null;
    const galeAlert = data?.galeAlert ?? null;
    const signal20 = signal?.signal20 ?? null;  // nested inside the DualSignalResult

    console.log(
      `[Aviator Ext] ✅ ${multiplier}x → 1.5x:${signal?.signal}(${signal?.confidence?.toFixed(0)}%) 2x:${signal20?.signal}(${signal20?.confidence?.toFixed(0)}%) gale=${galeAlert} [${source}]`,
    );

    await updateLocalHistory(multiplier, "ok", null, signal, galeAlert, signal20);
    showNotification(multiplier, signal, galeAlert);
    return { signal, galeAlert, signal20 };

  } catch (err) {
    console.error("[Aviator Ext] ❌ Send failed:", err.message);
    await updateLocalHistory(multiplier, "error", err.message);
    return null;
  }
}

// ─── History storage ──────────────────────────────────────────────────────────
async function updateLocalHistory(multiplier, status, errorMsg, signal, galeAlert, signal20) {
  const { lastRounds = [], totalCaptures = 0 } = await chrome.storage.local.get([
    "lastRounds",
    "totalCaptures",
  ]);

  const entry = {
    multiplier,
    status,
    signal: signal?.signal ?? null,
    confidence: signal?.confidence ?? null,
    signal20: signal20?.signal ?? null,
    confidence20: signal20?.confidence ?? null,
    galeAlert: galeAlert ?? null,
    time: new Date().toISOString(),
    error: errorMsg ?? null,
  };

  const updated = [entry, ...lastRounds].slice(0, 30);
  const newTotal = status === "ok" ? totalCaptures + 1 : totalCaptures;
  await chrome.storage.local.set({ lastRounds: updated, totalCaptures: newTotal });
}

// ─── Notifications ────────────────────────────────────────────────────────────
function showNotification(multiplier, signal, galeAlert) {
  const GALE_LABELS = {
    WIN_DIRECT: "✅ GANADA DIRECTA",
    WIN_GALE: "🔄 GANADA CON GALE",
    GALE_TRIGGERED: "⚠️ GALE — Aplica doble apuesta",
    LOSS_FINAL: "❌ PÉRDIDA TOTAL",
  };
  const galeMsg = galeAlert ? GALE_LABELS[galeAlert] : null;
  const isEnter = signal?.signal === "ENTER";
  const nextMsg = signal
    ? `${isEnter ? "✅ ENTRAR" : "⏳ ESPERAR"} | ${signal.confidence?.toFixed(0)}%`
    : "";
  try {
    chrome.notifications.create({
      type: "basic",
      iconUrl: "icons/icon128.png",
      title: `Aviator: ${multiplier.toFixed(2)}x ${galeMsg ? "— " + galeMsg : ""}`,
      message: nextMsg,
      priority: galeAlert === "GALE_TRIGGERED" ? 2 : isEnter ? 2 : 0,
    });
  } catch { /* notifications optional */ }
}
