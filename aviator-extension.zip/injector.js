/**
 * Injector - runs in MAIN world (same scope as the page JS)
 * Intercepts WebSocket + Fetch + XHR + postMessage + DOM to capture Aviator round results.
 * v2.0 - handles binary frames, Spribe-specific selectors, XHR, improved reliability
 */
(function () {
  "use strict";

  if (window.__aviatorInjected) return;
  window.__aviatorInjected = true;

  // ─── Deduplication ──────────────────────────────────────────────────────────
  let lastDispatch = { mult: null, time: 0 };

  function dispatchRound(multiplier, source) {
    const now = Date.now();
    if (lastDispatch.mult === multiplier && now - lastDispatch.time < 2000) return;
    lastDispatch = { mult: multiplier, time: now };

    const evt = new CustomEvent("__aviator_round", {
      detail: { multiplier: parseFloat(multiplier.toFixed(2)) },
      bubbles: true,
    });
    document.dispatchEvent(evt);
    console.log(`[Aviator Ext] ✅ Round captured via ${source}: ${multiplier.toFixed(2)}x`);
  }

  // ─── Multiplier extraction ──────────────────────────────────────────────────
  function extractMultiplier(obj) {
    if (!obj || typeof obj !== "object") return null;

    // Spribe-specific fields (crash_factor is primary)
    const keys = [
      "crash_factor", "crashFactor", "x", "koeff", "coefficient",
      "multiplier", "factor", "result", "coeff", "k",
      "value", "rate", "odd", "odds", "win", "winMultiplier",
      "crash", "cashout", "payout",
    ];

    for (const key of keys) {
      if (key in obj) {
        const n = parseFloat(obj[key]);
        if (!isNaN(n) && n >= 1.0 && n <= 10000) return n;
      }
    }

    // Recurse into nested objects (Spribe nests deeply: message → data → game_result → crash_factor)
    const nested = [
      "data", "result", "payload", "game", "round", "info",
      "game_result", "message", "event_data", "crash", "details",
    ];
    for (const key of nested) {
      if (obj[key] && typeof obj[key] === "object") {
        const found = extractMultiplier(obj[key]);
        if (found) return found;
      }
    }

    return null;
  }

  // ─── Action detection ───────────────────────────────────────────────────────
  function isEndAction(action) {
    if (!action) return false;
    const s = String(action).toLowerCase();
    return (
      s.includes("finish") || s.includes("crash") || s.includes("end") ||
      s.includes("stop") || s.includes("lose") || s.includes("bust") ||
      s.includes("round_result") || s.includes("game_result") ||
      s.includes("result") || s.includes("payout") || s.includes("cashout") ||
      s === "stats" || s === "game_stats" || s === "history"
    );
  }

  // ─── Fast string scan (no JSON parse needed) ────────────────────────────────
  function scanStringForMultiplier(text) {
    if (typeof text !== "string") return null;
    const patterns = [
      /"crash_factor"\s*:\s*([\d.]+)/,
      /"coefficient"\s*:\s*([\d.]+)/,
      /"x"\s*:\s*([\d.]+)/,
      /"koeff"\s*:\s*([\d.]+)/,
      /"factor"\s*:\s*([\d.]+)/,
    ];
    for (const re of patterns) {
      const m = text.match(re);
      if (m) {
        const n = parseFloat(m[1]);
        if (!isNaN(n) && n >= 1.0 && n <= 10000) return n;
      }
    }
    return null;
  }

  function tryParse(text) {
    if (typeof text !== "string") return null;
    const s = text.trim();
    if (!s.startsWith("{") && !s.startsWith("[")) return null;
    try { return JSON.parse(s); } catch { return null; }
  }

  // ─── Core message processor ─────────────────────────────────────────────────
  function processMessage(raw, source) {
    let text = null;

    if (typeof raw === "string") {
      text = raw;
    } else if (raw instanceof ArrayBuffer) {
      // Decode binary frames as UTF-8 — Spribe uses binary WebSocket in some environments
      try { text = new TextDecoder("utf-8").decode(raw); } catch { return; }
    } else if (raw instanceof Blob) {
      raw.arrayBuffer().then((buf) => {
        try {
          processMessage(new TextDecoder("utf-8").decode(buf), source + ":blob");
        } catch {}
      });
      return;
    }

    if (!text || text.length < 3) return;

    // Fast path: scan string for known field names
    const directMult = scanStringForMultiplier(text);
    if (directMult) {
      dispatchRound(directMult, source + ":scan");
      return;
    }

    const parsed = tryParse(text);
    if (!parsed) return;

    const items = Array.isArray(parsed) ? parsed : [parsed];

    for (const item of items) {
      if (!item || typeof item !== "object") continue;

      const action = item.action ?? item.type ?? item.event ??
        item.cmd ?? item.command ?? item.msg ??
        item.message?.type ?? item.name ?? item.event_name;

      if (isEndAction(action)) {
        const mult = extractMultiplier(item);
        if (mult) { dispatchRound(mult, source + ":action"); return; }
      }

      // Fallback: any crash-related payload with a number
      if (
        text.includes("crash") || text.includes("finish") ||
        text.includes("result") || text.includes("koeff") ||
        text.includes("crash_factor")
      ) {
        const mult = extractMultiplier(item);
        if (mult) { dispatchRound(mult, source + ":fallback"); return; }
      }
    }
  }

  // ─── WebSocket Interception ─────────────────────────────────────────────────
  const OriginalWebSocket = window.WebSocket;

  class PatchedWebSocket extends OriginalWebSocket {
    constructor(url, protocols) {
      super(url, protocols);
      const wsUrl = typeof url === "string" ? url : (url?.href ?? "");
      this.addEventListener("message", (event) => {
        try { processMessage(event.data, "ws:" + (wsUrl.split("/")[2] ?? "?")); } catch {}
      });
    }
  }

  Object.defineProperty(PatchedWebSocket, "CONNECTING", { value: OriginalWebSocket.CONNECTING });
  Object.defineProperty(PatchedWebSocket, "OPEN", { value: OriginalWebSocket.OPEN });
  Object.defineProperty(PatchedWebSocket, "CLOSING", { value: OriginalWebSocket.CLOSING });
  Object.defineProperty(PatchedWebSocket, "CLOSED", { value: OriginalWebSocket.CLOSED });
  window.WebSocket = PatchedWebSocket;

  // ─── Fetch Interception ─────────────────────────────────────────────────────
  const OriginalFetch = window.fetch;
  window.fetch = async function (...args) {
    const res = await OriginalFetch.apply(this, args);
    try {
      const url = typeof args[0] === "string" ? args[0] : (args[0]?.url ?? "");
      if (
        url.includes("history") || url.includes("rounds") ||
        url.includes("results") || url.includes("bets") ||
        url.includes("games") || url.includes("crash") ||
        url.includes("game_result") || url.includes("spribe")
      ) {
        const clone = res.clone();
        clone.text().then((text) => {
          const mult = scanStringForMultiplier(text);
          if (mult) { dispatchRound(mult, "fetch:scan"); return; }
          const json = tryParse(text);
          if (!json) return;
          const arr = Array.isArray(json) ? json :
            json?.data ?? json?.rounds ?? json?.results ?? json?.games ?? [];
          if (Array.isArray(arr) && arr.length > 0) {
            const m = extractMultiplier(arr[0]);
            if (m) { dispatchRound(m, "fetch:array"); return; }
          }
          const m = extractMultiplier(json);
          if (m) dispatchRound(m, "fetch:obj");
        }).catch(() => {});
      }
    } catch {}
    return res;
  };

  // ─── XHR Interception ──────────────────────────────────────────────────────
  const OriginalXHR = window.XMLHttpRequest;
  function PatchedXHR() {
    const xhr = new OriginalXHR();
    const origOpen = xhr.open.bind(xhr);
    xhr.open = function (method, url, ...rest) {
      xhr._url = String(url ?? "");
      return origOpen(method, url, ...rest);
    };
    xhr.addEventListener("load", function () {
      try {
        const url = xhr._url ?? "";
        if (
          url.includes("history") || url.includes("rounds") ||
          url.includes("result") || url.includes("crash") || url.includes("spribe")
        ) {
          const mult = scanStringForMultiplier(xhr.responseText);
          if (mult) dispatchRound(mult, "xhr");
        }
      } catch {}
    });
    return xhr;
  }
  PatchedXHR.prototype = OriginalXHR.prototype;
  window.XMLHttpRequest = PatchedXHR;

  // ─── postMessage Listener ───────────────────────────────────────────────────
  window.addEventListener("message", (event) => {
    try {
      const raw = typeof event.data === "string" ? event.data : JSON.stringify(event.data);
      processMessage(raw, "postmsg");
    } catch {}
  });

  // ─── DOM Scanner — Spribe-specific selectors ────────────────────────────────
  // Known Spribe Aviator class patterns for the crash multiplier display
  const SPRIBE_SELECTORS = [
    "[class*='paycoef']", "[class*='payCoef']",
    "[class*='crash-coef']", "[class*='crashCoef']",
    "[class*='bubble-coef']", "[class*='bubbleCoef']",
    "[class*='coeff']", "[class*='coefficient']",
    "[class*='multiplier']", "[class*='cashout']",
    "[class*='coef']", "[class*='result']",
    "#crash-coeff", "#multiplier", "#coefficient",
    // Additional Spribe patterns found in source analysis
    "[class*='game-coef']", "[class*='gameCoef']",
    "[class*='win-coef']", "[class*='winCoef']",
    "[class*='payout-coef']",
  ].join(", ");

  let frozenCount = 0;
  let lastFrozenMult = null;

  setInterval(() => {
    try {
      // Search in current doc + all accessible iframes
      const docs = [document];
      document.querySelectorAll("iframe").forEach((f) => {
        try { if (f.contentDocument) docs.push(f.contentDocument); } catch {}
      });

      for (const doc of docs) {
        let elements;
        try { elements = doc.querySelectorAll(SPRIBE_SELECTORS); } catch { continue; }

        for (const el of elements) {
          try {
            const raw = (el.textContent ?? "").trim()
              .replace(",", ".").replace("×", "").replace(/x$/i, "").trim();
            const n = parseFloat(raw);
            if (isNaN(n) || n < 1.0 || n > 10000) continue;

            if (n === lastFrozenMult) {
              frozenCount++;
            } else {
              lastFrozenMult = n;
              frozenCount = 1;
            }

            // Stable for ~3 checks (~2.4s) = crash result
            if (frozenCount === 3) {
              dispatchRound(n, "dom");
              frozenCount = 0;
              lastFrozenMult = null;
            }
          } catch {}
        }
      }
    } catch {}
  }, 800);

  console.log("[Aviator Ext] 🚀 Injector v2.0 loaded — binary WS + XHR + DOM auto-capture active");
})();
